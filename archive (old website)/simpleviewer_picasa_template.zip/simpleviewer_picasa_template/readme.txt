-----------------------------------------------
SimpleViewer Picasa Template v1.8
-----------------------------------------------

-----------------------------------------------
To install the SimpleViewer Picasa Template
-----------------------------------------------
Copy this folder into your Picasa web templates folder (usually C:\Program Files\Picasa2\web\templates).

-----------------------------------------------
To create a SimpleViewer Gallery using Picasa
-----------------------------------------------
1) Select your Images in Picasa
2) Click 'Folder -> Export as Web Page...' Select SimpleViewer template.

For additonal instructions, check here: 
http://www.airtightinteractive.com/simpleviewer/auto_desktop_instruct.html

-----------------------------------------------
Credits
-----------------------------------------------
SimpleViewer Picasa Template by Problemdog (problemdog@gmail.com)
SimpleViewer created by Airtight Interactive (www.airtightinteractive.com)